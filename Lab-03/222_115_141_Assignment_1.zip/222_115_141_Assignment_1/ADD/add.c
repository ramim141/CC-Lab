#include<stdio.h>

int main()
{
    int id1, id2;
    printf("Enter two numbers: ");
    scanf("%d %d", &id1, &id2);
    printf("Sum = %d", id1 + id2);
    return 0;
}