#include<stdio.h>

int main()
{

    int id1, id2;
    printf("Enter two integers: ");
    scanf("%d %d", &id1, &id2);
    printf("The difference of two integers is: %d\n", id1 - id2);

    return 0;
}